# tokenbucket
Token bucket implementation in Go
